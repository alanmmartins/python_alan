genero = input ('digite a letra correpondente ao genero (m) ou (f) : ')
if genero == 'm' or genero == 'f':
    print ('Genero validado')
else:
    print ('Genero invalid')    