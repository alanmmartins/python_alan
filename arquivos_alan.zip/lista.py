""" nome = ['café','pao de queijo']
print(type(nome))
 """
nome =['café','pao de queijo',1,1.2,3]
print(type(nome[0]))
print(type(nome[1]))
print(type(nome[2]))
print(type(nome[3]))
print(type(nome[4]))
print(type(nome[-2]))        
print(type(nome[-2]))