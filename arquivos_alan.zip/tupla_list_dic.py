nome = ('cafe','pao de queijo','bolo')
print(type(nome))

nome = ['cafe','pao de queijo','bolo']
print(type(nome))
       
nome = {'cafe':'açucar',
        'pao':'queijo',
        'bolo':'chocolate'}       
print(type(nome))
print(nome['segundo'])