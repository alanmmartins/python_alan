cont = 0
n = int(input("Number is : "))
while cont < 100:
    cont+=1
    m = cont* n
    print(f'{n} x {cont} = {m}')
print(f'essa e a tabuada o {n}')    