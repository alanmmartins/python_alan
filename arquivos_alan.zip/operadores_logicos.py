n1 = 5
n2 = 7
nome = 'Alan'
print (n1 == n2 and n1 >= n2)  
print (n1 != n2 or n1 >= n2)
print (n2 == n1 and n2 >= n1)
print(not n1 == n2)
print('an' in nome)
print ('an' not in nome)
