def minha_function(nome):
    #nome = 'python'
    print (f'definindo funções "def" {nome}!!!')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')
minha_function('python')

    
    