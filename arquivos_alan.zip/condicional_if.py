nome = input('nome: ')
idade = input('idade: ')
if idade >='18':
    print('pode tirar cnh')