print("ola")
print("mundo")
