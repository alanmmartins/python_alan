nome = 'alan'
idade = 23
altura = 1.78
teste = True
print (f'{nome} tem {idade} anos {altura}metros')