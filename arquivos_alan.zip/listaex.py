""" nome = [0,0,0,0,0]
for x in range(len(nome)):
    nome[x] =input('alan')
    nome[x] =input('nome')
    nome[x] =input('joao')
    nome[x] =input('alex')
    nome[x] =input('rob')
     
 """
""" nome = [0,0,0,0,0]
for x in range(len(nome)):
    nome[x] =input('nome do aluno')  
for x in range(len(nome)):
    print(nome[x])
     """
     
""" nome = [0,0,0,0,0]
for x in range(len(nome)):
    nome[x] =input('nome do aluno') 
print(nome)         
      """
n = [0]*10
for x in range(len(n)):
    n[x] = input(f'digite o {x+1} ºnumero :  ') 
for  x in range (len(n)):
    print(n[x])         