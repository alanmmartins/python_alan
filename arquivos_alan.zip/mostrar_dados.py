nome = 'alan'
idade = 23
altura = 1.78
print('o nome digitado foi : ' , nome)
print('a altura digitado foi : ' , altura)
print('{} tem {} anos'.format(nome, idade ))
      