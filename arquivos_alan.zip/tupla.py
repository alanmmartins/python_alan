""" nome = ('café','pao de queijo')
print(type(nome))
 """
nome = ('café','pao de queijo','bolos','mamão','leite')
print(nome[-2])
