def num(pnum, snum):
    print('primeiro numero:' + str(pnum) +'')
    print('segundo numero:' + str(snum) +'')
    print('soma: ',pnum + snum )
num(4, 8)
num(5, 9) 
num(6, 10)
num(7, 11)
num(8, 12)
num(9, 13)
   
   
def num(pnum, snum):
    print('primeiro numero:' + str(pnum) +'')
    print('segundo numero:' + str(snum) +'')
    print('soma: ',pnum - snum )
num(4, 8)
num(5, 9) 
num(6, 10)
num(7, 11)
num(8, 12)
num(9, 13)

def num(pnum, snum):
    print('primeiro numero:' + str(pnum) +'')
    print('segundo numero:' + str(snum) +'')
    print('soma: ',pnum * snum )
num(4, 8)
num(5, 9) 
num(6, 10)
num(7, 11)
num(8, 12)
num(9, 13)

def num(pnum, snum):
    print('primeiro numero:' + str(pnum) +'')
    print('segundo numero:' + str(snum) +'')
    print('soma: ',pnum / snum )
num(4, 8)
num(5, 9) 
num(6, 10)
num(7, 11)
num(8, 12)
num(9, 13)