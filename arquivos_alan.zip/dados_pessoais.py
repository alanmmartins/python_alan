nome = 'alan'
idade = 23
altura = 1.78
teste = True
print(type(nome))
print(type(idade))
print(type(altura))
print(type(teste))
