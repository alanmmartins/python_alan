class teste :
    pass
print(type(teste))