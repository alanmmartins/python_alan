nome = input ('digite o nome do usuario : ')
salario = int(input ('digite o salario : '))
print(f'salaro do (a){nome} e de r$ {salario}')
if salario >= 1300:
    print (f'o (A)  usuario {nome} ganha mais que o minimo')
else:
    print (f'o (A)  usuario {nome}  ganha menos do que o minimo')    
                     