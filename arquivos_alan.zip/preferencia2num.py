n1= 5
n2= 7
print(n1==n2)
print(n2==n1)
print(n1 >= n2)
print(n1 <= n2)
print(n1 > n2)
print(n1 < n2)
print(n1!=n2)
