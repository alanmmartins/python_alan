nome = 'alan'
idade = 23
altura = 1.78
teste = True
print ('o nome digitado foi:' , nome)
print ('o altura digitado foi:' , altura)
print ('{n} tem {i}anos'.format(n=nome, i=idade))